const audioPlayer = document.getElementById('audioPlayer');
const progressBar = document.getElementById('progressBar');

audioPlayer.addEventListener('play', function() {
    console.log('Audio is playing');
});

audioPlayer.addEventListener('pause', function() {
    console.log('Audio is paused');
});

audioPlayer.addEventListener('ended', function() {
    console.log('Audio has ended');
});

// Aggiungo la funzionalità di cliccare sulla traccia per saltare a una posizione specifica
progressBar.addEventListener('click', function(e) {
    const boundingRect = this.getBoundingClientRect();
    const offsetX = e.clientX - boundingRect.left;
    const totalWidth = this.clientWidth;
    const duration = audioPlayer.duration;

    const newPosition = (offsetX / totalWidth) * duration;
    audioPlayer.currentTime = newPosition;
});

// Aggiorno la barra di avanzamento della traccia
audioPlayer.addEventListener('timeupdate', function() {
    const currentTime = this.currentTime;
    const duration = this.duration;
    const progressPercent = (currentTime / duration) * 100;
    progressBar.style.width = progressPercent + '%';
});